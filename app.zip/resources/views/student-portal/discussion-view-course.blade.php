@extends('layouts.student-portal')
@section('title',$course->name)
@section('content')
    <section class="bg-dark-alt border-radius-sm py-0 py-sm-3">
        <div class="container">
            <div class="row ">
                <div class="col-lg-8">
                    <!-- Badge -->

                    <!-- Title -->
                    <h2 class="text-white mt-3">
                        @if(!empty($course->name))
                            {{$course->name}}
                        @endif
                    </h2>

                    <!-- Content -->
                    <ul class="list-inline mb-0 ">
                        <li class="list-inline-item text-sm me-3 mb-1 mb-sm-0 text-white"><i class="bi bi-patch-exclamation-fill text-danger"></i>{{__('Updated')}}
                            @if(!empty($course->name))
                                {{ \Carbon\Carbon::parse($course->updated_at)->diffForHumans() }}

                            @endif</li>

                    </ul>
                </div>
            </div>
        </div>
    </section>


    <section class="mt-4">

        <div class="" data-sticky-container>
            <div class="row g-4">
                <!-- Main content START -->
                <div class="col-xl-8">

                    <div class="row g-4">
                        <!-- Title START -->
                        <!-- Title END -->
                        <!-- Image and video -->
                        <div class="col-12 position-relative">
                            @if(empty($course->image))
                                <img src="{{ url('public') }}/img/placeholder.jpeg"
                                     class="w-100 border-radius-sm">
                            @else
                                <img src="{{ url('public') }}/uploads/{{$course->image}}" class="w-100  border-radius-sm ">
                            @endif
                        </div>

                        <!-- About course START -->

                        <div class="text-center">
                            <ul class="nav  mt-2 ">

                                <li class="nav-item">
                                    <a class="nav-link fw-bolder" href="{{ url('student/my-course-details')}}/?id={{$course->id}}">{{__('Course Description')}}</a>
                                </li>


                                <li class="nav-item">
                                    <a href="{{ url('student/my-course-lessons')}}/?id={{$course->id}}" class="  nav-link fw-bolder">{{__('Sessions')}}</a>
                                </li>
                                <li class="nav-item">
                                    <a href="" class="@if(($selected_nav ?? '') === 'student-course-discussion') active @endif nav-link fw-bolder">{{__('Comments')}}</a>
                                </li>

                            </ul>
                            <hr>
                        </div>
                        <!-- About course END -->

                        <!-- Curriculum START -->
                        <div class="col-12">
                            <div class="card rounded-3">
                                <!-- Card header START -->
                                <!-- Card body START -->
                                <div class="card-body mt-2 mt-sm-4">

                                    <!-- Review item START -->
                                    @foreach($comments as $comment)
                                        <div class="d-sm-flex">
                                            <!-- Avatar image -->

                                            @if($comment->type == 'Admin')
                                                @if(!empty($users[$comment->admin_id]->photo))
                                                    <a href="javascript:" class=" avatar avatar-md rounded-circle ">
                                                        <img alt="" class="avatar rounded-circle flex-shrink-0"
                                                             src="{{ url('public') }}/uploads/{{$users[$comment->admin_id]->photo}}">
                                                    </a>
                                                @else
                                                    <div
                                                            class="avatar avatar-md rounded-circle bg-purple-light  border-radius-md p-2">
                                                        <h6 class="text-purple mt-1">{{$users[$comment->admin_id]->first_name[0]}}{{$users[$comment->admin_id]->last_name[0]}}</h6>
                                                    </div>
                                                @endif


                                            @elseif($comment->type == 'Student')
                                                @if(!empty($students[$comment->student_id]->photo))
                                                    <a href="javascript:" class=" avatar avatar-md rounded-circle ">
                                                        <img alt="" class="avatar rounded-circle flex-shrink-0"
                                                             src="{{ url('public') }}/uploads/{{$students[$comment->student_id]->photo}}">
                                                    </a>
                                                @else
                                                    <div
                                                            class="avatar avatar-md rounded-circle bg-purple-light  border-radius-md p-2">
                                                        <h6 class="text-purple mt-1">{{$students[$comment->student_id]->first_name[0]}}{{$students[$comment->student_id]->last_name[0]}}</h6>
                                                    </div>
                                                @endif

                                            @endif

                                            <div>
                                                <div class=" ms-2 mb-3 d-sm-flex justify-content-sm-between align-items-center">
                                                    <!-- Title -->
                                                    <div>
                                                        @if($comment->type == 'Admin')
                                                            @if(!empty($users[$comment->admin_id]->first_name))

                                                                <h5>{{$users[$comment->admin_id]->first_name}}{{$users[$comment->admin_id]->last_name}}</h5>

                                                            @endif


                                                        @elseif($comment->type == 'Student')
                                                            @if(!empty($students[$comment->student_id]->first_name))
                                                                <h6 class="m-0">{{$students[$comment->student_id]->first_name}} {{$students[$comment->student_id]->last_name}}</h6>

                                                            @endif

                                                        @endif

                                                        <span class="me-3 small">{{$comment->created_at}} </span>
                                                    </div>
                                                    <!-- Review star -->
                                                </div>
                                                <!-- Content -->
                                                <p class="ms-2">{{$comment->message}}</p>
                                                <!-- Button -->

                                            </div>
                                        </div>
                                @endforeach
                                <!-- Divider -->
                                    <div class="" id="collapseComment">
                                        <form action="{{ url('student/save-course-comment')}}" method="post">
                                            <div class="d-flex mt-3">
                                                <textarea class="form-control mb-0" placeholder="Add a comment..." rows="2" spellcheck="false" name="message"></textarea>
                                                <input type="hidden" name="course_id" value="{{$course->id}}">
                                                @csrf

                                                <button type="submit" class="btn btn-sm btn-primary-soft ms-2 px-4 mb-0 flex-shrink-0"><i class="fas fa-paper-plane fs-5"></i></button>
                                            </div>
                                        </form>

                                    </div>




                                </div>
                                <!-- Card body START -->
                            </div>
                        </div>
                        <!-- Curriculum END -->

                        <!-- FAQs START -->

                        <!-- FAQs END -->
                    </div>
                </div>
                <!-- Main content END -->

                <!-- Right sidebar START -->
                <div class="col-xl-4">
                    <div data-sticky data-margin-top="80" data-sticky-for="768">
                        <div class="row g-4">
                            <div class="col-md-6 col-xl-12">
                                <!-- Course info START -->
                                <div class="card card-body p-4">
                                    <!-- Price and share button -->
                                    <div class="d-flex justify-content-between align-items-center">
                                        <!-- Price -->
                                        <h3 class="fw-bold mb-0 me-2"
                                        >@if(!empty($course->price))
                                               INR {{$course->price}}

                                            @endif
                                        </h3>
                                        <!-- Share button with dropdown -->

                                    </div>

                                    <!-- Divider -->
                                    <hr>

                                    <!-- Title -->
                                    <h5 class="mb-3">{{__('This course includes')}}</h5>
                                    <ul class="list-group  border-0">
                                        <li class="list-group-item px-0 d-flex justify-content-between">
                                            <span class="h6 fw-light mb-0 ">

<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" class="feather feather-book-open text-info me-2"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"></path><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"></path></svg>

                                                {{__('Sessions')}}
                                            </span>
                                            <span> @if(!empty($course))
                                                    {!! getTotalLesson($course->id) !!}


                                                @endif
                                            </span>
                                        </li>
                                        <li class="list-group-item px-0 d-flex justify-content-between">
                                            <span class="h6 fw-light mb-0">

<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" class="feather feather-clock text-info me-2"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
                                                {{__('Duration')}}
                                            </span>
                                            <span>
                                                @if(!empty($course->duration))
                                                    {{$course->duration}}

                                                @endif
                                            </span>
                                        </li>
                                        <li class="list-group-item px-0 d-flex justify-content-between">
                                            <span class="h6 fw-light mb-0">

<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" class="feather feather-filter text-info me-2"><polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"></polygon></svg>
                                                {{__('Level')}}
                                            </span>
                                            <span>
                                                @if (!empty($course->level))
                                                    {{$course->level}}
                                                @endif
                                            </span>
                                        </li>

                                        <li class="list-group-item px-0 d-flex justify-content-between">
                                            <span class="h6 fw-light mb-0">

<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" class="feather feather-calendar text-info me-2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
                                                {{__('Deadline')}}
                                            </span>
                                            <span>
                                                @if(!empty($course->deadline))
                                                    {{(\App\Supports\DateSupport::parse($course->deadline))->format(config('app.date_format'))}}
                                                @endif

                                            </span>
                                        </li>
                                        <li class="list-group-item px-0 d-flex justify-content-between">
                                            <span class="h6 fw-light mb-0">

<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" class="feather feather-award text-info me-2"><circle cx="12" cy="8" r="7"></circle><polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88"></polyline></svg>
                                                {{__('Certificate')}}</span>
                                            <span>
                                                @if (!empty($course->certificate))
                                                    {{$course->certificate}}

                                                @endif
                                            </span>
                                        </li>
                                    </ul>
                                    <!-- Divider -->
                                    <hr>

                                    <!-- Instructor info -->
                                    <div class="d-sm-flex align-items-center">
                                        <!-- Avatar image -->
                                        <div class="avatar avatar-xl">

                                            @if(!empty($users[$course->admin_id]->photo))
                                                <a href="javascript:" class="ms-3 mt-4 avatar rounded-circle border border-secondary">
                                                    <img alt="" class="p-1" src="{{ url('public') }}/uploads/{{$users[$course->admin_id]->photo}}">
                                                </a>
                                            @else
                                                <div class="avatar ms-3   mt-4 rounded-circle bg-info-light  border-radius-md p-2">
                                                    <h6 class="text-info mt-1">{{$users[$course->admin_id]->first_name[0]}}{{$users[$course->admin_id]->last_name[0]}}</h6>
                                                </div>
                                            @endif


                                        </div>
                                        <div class="ms-sm-3 mt-2 mt-sm-0">
                                            <h5 class="mb-0"><a href="#">{{__('By')}}
                                                {{$users[$course->admin_id]->first_name}} {{$users[$course->admin_id]->last_name}}</h5>

                                        </div>
                                    </div>
                                    <!-- Course info END -->
                                </div>
                                <!-- <div class="modal fade" id="review" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <form action="{{ url('student/save-review')}}" method="post">

                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">{{__('Review this course')}}</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    @if ($errors->any())
                                                        <div class="alert bg-pink-light text-danger">
                                                            <ul class="list-unstyled">
                                                                @foreach ($errors->all() as $error)
                                                                    <li>{{ $error }}</li>
                                                                @endforeach
                                                            </ul>
                                                        </div>
                                                    @endif

                                                    <div class="mb-2 mt-3">
                                                        <label for="exampleFormControlTextarea1" class="form-label">{{__('Write your Review')}}</label>
                                                        <textarea class="form-control" name="review" id="exampleFormControlTextarea1" rows="4">{{$review->review ?? old('review') ?? ''}}</textarea>
                                                    </div>

                                                    <input type="hidden" id="star_count" name="star_count" value="{{$review->star_count ?? ''}}">

                                                </div>

                                                @csrf

                                                <input type="hidden" name="course_id" value="{{$course->id}}">

                                                <div class="ms-3 mb-4">
                                                    <button type="button" class="btn btn-sm bg-pink-light text-danger shadow-none" data-bs-dismiss="modal">{{__('Cancel')}}</button>
                                                    <button type="submit" class="btn btn-sm bg-purple-light text-purple shadow-none">{{__('Save Review')}}</button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
 -->

                                <!-- Tags START -->
                                <div class="col-md-6 col-xl-12">
                                    <div class="card card-body  p-4">
                                        <h5 class="mb-3">{{__('Category')}}</h5>
                                        <ul class="list-inline mb-0">

                                            <li class="list-inline-item">
                                                @if(!empty($categories[$course->category_id]))
                                                    <span class="badge bg-purple-light mb-3 mt-4">
                        @if(isset($categories[$course->category_id]))
                                                            {{$categories[$course->category_id]->name}}
                                                        @endif
                                                        @endif
                    </span>
                                            </li>



                                        </ul>
                                    </div>
                                </div>
                                <!-- Tags END -->
                            </div><!-- Row End -->
                        </div>
                    </div>
                    <!-- Right sidebar END -->

                </div><!-- Row END -->
            </div>
    </section>



@endsection
@section('script')
    <script>
        const ratingStars = [...document.getElementsByClassName("rating__star")];

        ratingStars.forEach(function(star, index) {
            star.addEventListener('click', function() {
                ratingStars.forEach(function(star) {
                    star.classList.remove('fas', 'fa-star');
                    star.classList.add('far', 'fa-star');
                });
                for (let i = 0; i <= index; i++) {
                    ratingStars[i].classList.remove('far', 'fa-star');
                    ratingStars[i].classList.add('fas', 'fa-star');
                }
                document.getElementById('star_count').value = index + 1;
            });
        });

        // Set star count

        if(document.getElementById('star_count').value > 0) {
            console.log(document.getElementById('star_count').value);
            for (let i = 0; i < document.getElementById('star_count').value; i++) {
                ratingStars[i].classList.remove('far', 'fa-star');
                ratingStars[i].classList.add('fas', 'fa-star');
            }
        }

    </script>

@endsection